package com.example.prime;

import android.content.Context;

/**
 * Prime number structure.
 */
public class Prime {

  public String name; // not used; potential for expansion
  public Integer pnumber;
}
